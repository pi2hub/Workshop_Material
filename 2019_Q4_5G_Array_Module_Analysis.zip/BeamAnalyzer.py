# =============================================================================
# Initialize AEDT Environment
# =============================================================================
import os, sys, re, clr, math, json, time, random, string
from collections import OrderedDict
try:
    dll_dir='C:/Program Files/AnsysEM/AnsysEM19.3/Win64/common/IronPython/DLLs'
    if not os.path.isdir(dll_dir):
        raise Exception 
except:
    m=re.search('(.*Win64)', __file__)
    dll_dir=m.group(1)+'/common/IronPython/DLLs'
finally:
    sys.path.append(dll_dir)
    clr.AddReference('IronPython.Wpf')  
    
    import wpf
    from System.Windows import Window, Visibility
    from System.Windows.Forms import OpenFileDialog, SaveFileDialog, DialogResult, FolderBrowserDialog
    os.chdir(os.path.dirname(__file__))


# =============================================================================
# Save far field of each element in antenna array
# =============================================================================
oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()

def getallports():
    oModule=oDesign.GetModule("Solutions")
    return oModule.GetAllSources()


def savefield(solution, frequency, variation, path):
    try:
        ports=getallports()
        oModule1=oDesign.GetModule("Solutions")
        oModule2=oDesign.GetModule("RadField")
        oModule2.InsertFarFieldSphereSetup(["NAME:ffd","UseCustomRadiationSurface:=",False,"ThetaStart:=","0deg","ThetaStop:=","180deg","ThetaStep:=","1deg","PhiStart:=","0deg","PhiStop:=","360deg","PhiStep:=","1deg","UseLocalCS:=",False])
        
        for i in ports:
            allports=[]
            for j in ports:
                if j == i:
                    allports.append(["Name:=","{}:1".format(j),"Magnitude:=","1W","Phase:=","0deg"])
                else:
                    allports.append(["Name:=","{}:1".format(j),"Magnitude:=","0W","Phase:=","0deg"])

            oModule1.EditSources([["IncludePortPostProcessing:=",False,"SpecifySystemPower:=",False]]+allports)
            ffdfile='{}/{}.ffd'.format(path, i)
            oModule2.ExportRadiationFieldsToFile(["ExportFileName:=",ffdfile,"SetupName:=","ffd","IntrinsicVariationKey:=","Freq={}".format(frequency),"DesignVariationKey:=",variation,"SolutionName:=",solution])
    except:
        pass
    finally:
        oModule2.DeleteFarFieldSetup(["ffd"])

# =============================================================================
# Access Simulation Information
# =============================================================================
class solutions():
    def __init__(self):
        oProject = oDesktop.GetActiveProject()
        self.oDesign = oProject.GetActiveDesign()
        
    def getReportType(self):
        oModule=self.oDesign.GetModule("ReportSetup")
        return oModule.GetAvailableReportTypes()

    def getAvailableSolution(self, ReportType):
        oModule=self.oDesign.GetModule("ReportSetup")
        return oModule.GetAvailableSolutions(ReportType)
    
    def getFrequency(self, Solution):
        oModule=self.oDesign.GetModule("Solutions")
        return oModule.GetSolveRangeInfo(Solution)
        
    def getVariations(self, Solution):
        oModule=self.oDesign.GetModule("Solutions")
        return oModule.GetAvailableVariations(Solution)

def randomString(stringLength=4):
    """Generate a random string of fixed length """
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(stringLength))
    
def setExcitation(weighting):
    oModule=oDesign.GetModule("Solutions")
    
    dic={i:(0,0) for i in getallports()}
    for key in weighting:
        dic[key] = weighting[key]

    def single_port(name, exc):
        mag, phase=exc
        return ["Name:=","{}:1".format(name),"Magnitude:=","{}W".format(mag),"Phase:=","{}deg".format(phase)]
    
    allport=[single_port(i, dic[i]) for i in dic]    
    oModule.EditSources([["IncludePortPostProcessing:=",False,"SpecifySystemPower:=",False]]+allport)

    
# =============================================================================
# GUI Interaction
# =============================================================================
class MyWindow(Window):
    cb=[]
    def __init__(self):
        global cb
        wpf.LoadComponent(self, 'BeamAnalyzer.xaml')
        try:
            with open('BeamAnalyzer.json', 'r') as fp:
                config=json.load(fp)
                self.beam_TB.Text = config['file']
                self.beam_CB.SelectedItem=config['angle']
        except:
            pass
            
        cb =[self.cb0, self.cb1, self.cb2, self.cb3, self.cb4, self.cb5, self.cb6, self.cb7, self.cb8, self.cb9]
        cb+=[self.cb10, self.cb11, self.cb12, self.cb13, self.cb14, self.cb15, self.cb16, self.cb17, self.cb18, self.cb19]
        cb+=[self.cb20, self.cb21, self.cb22, self.cb23, self.cb24, self.cb25, self.cb26, self.cb27, self.cb28, self.cb29]
        cb+=[self.cb30, self.cb31, self.cb32, self.cb33, self.cb34, self.cb35, self.cb36, self.cb37, self.cb38, self.cb39]
        cb+=[self.cb40, self.cb41, self.cb42, self.cb43, self.cb44, self.cb45, self.cb46, self.cb47, self.cb48, self.cb49]
        self._initialize()
        
    def _initialize(self):
        self.solu=solutions()
        s=self.solu.getAvailableSolution('Far Fields')
        for i in s:
            self.solution_CB.Items.Add(i)
        self.solution_CB.SelectedIndex = 0

        oProject = oDesktop.GetActiveProject()
        oDesign = oProject.GetActiveDesign()
        self.path='{}{}.aedtresults/{}.results'.format(oProject.GetPath(), oProject.GetName(), oDesign.GetName())
        
    def solution_CB_SelectionChanged(self, sender, e):
        global cb
        for i in cb:
            i.Visibility=Visibility.Collapsed
            i.IsChecked=False
        
        f=self.solu.getFrequency(self.solution_CB.SelectedItem)
        for n, i in enumerate(f):
            cb[n].Content=i
            cb[n].Visibility=Visibility.Visible
        
        try:
            self.variation_CB.Items.Clear()        
            for v in self.solu.getVariations(self.solution_CB.SelectedItem):
                self.variation_CB.Items.Add(v)
            self.variation_CB.SelectedIndex = 0
        except:
            pass
    
    
    def save_BT_Click(self, sender, e):    
        dialog = FolderBrowserDialog()
        if dialog.ShowDialog() == DialogResult.OK:
            path = dialog.SelectedPath
            oDesktop.ClearMessages("", "", 2)
            
            solution=self.solution_CB.SelectedItem
            variation=self.variation_CB.SelectedItem
            
            freq=[i.Content for i in cb if i.IsChecked]
            for i in freq:
                directory='{}/{}'.format(path,i)
                try:
                    os.mkdir(directory)
                    AddWarningMessage('Save far field .ffd at {}Hz under {}'.format(i, directory))    
                    savefield(solution, i, variation, directory)                
                except:
                    AddWarningMessage('Failed!')
                    return
            AddWarningMessage('Export Completed!')

    def beam_BT_Click(self, sender, e):
        dialog = OpenFileDialog()
        dialog.Filter = "phase table(*.json)|*.json"

        if dialog.ShowDialog() == DialogResult.OK:
            self.beam_TB.Text=dialog.FileName

    def beam_TB_TextChanged(self, sender, e):
        with open(self.beam_TB.Text, 'r') as fp:
            self.portname, self.data = json.load(fp, object_pairs_hook=OrderedDict)
        for i in self.data:
            self.beam_CB.Items.Add(i)
        self.beam_CB.SelectedIndex = 0        
        
    def beam_CB_SelectionChanged(self, sender, e):
        phases, gain=self.data[self.beam_CB.SelectedItem]
        self.gain_LB.Content='Gain: {}'.format(gain)
        weighting={i:(1,j) for i,j in zip(self.portname, phases)}
        setExcitation(weighting)
        
    def Window_Closing(self, sender, e):
        with open('BeamAnalyzer.json', 'w') as fp:
            config={}
            config['file']=self.beam_TB.Text
            config['angle']=self.beam_CB.SelectedItem
            json.dump(config, fp, sort_keys=True, indent=4)       
# =============================================================================
# Launch Program      
# =============================================================================
MyWindow().ShowDialog()

