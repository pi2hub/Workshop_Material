
import ScriptEnv
ScriptEnv.Initialize("Ansoft.ElectronicsDesktop")
oDesktop.RestoreWindow()
oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()
oDesign.SetSolutionType("DrivenTerminal", False)
oModule = oDesign.GetModule("BoundarySetup")
oModule.AutoIdentifyPorts(
	[
		"NAME:Faces", 
		68
	], True, 
	[
		"NAME:ReferenceConductors", 
		"gnd"
	], "1", True)
oModule.AutoIdentifyPorts(
	[
		"NAME:Faces", 
		66
	], True, 
	[
		"NAME:ReferenceConductors", 
		"gnd"
	], "2", True)
oModule.AssignRadiation(
	[
		"NAME:Rad1",
		"Faces:="		, [63,67,65],
		"IsFssReference:="	, False,
		"IsForPML:="		, False
	])
oModule.EditDiffPairs(
	[
		"NAME:EditDiffPairs",
		[
			"NAME:Pair1",
			"PosBoundary:="		, "traceN_T1",
			"NegBoundary:="		, "traceP_T1",
			"CommonName:="		, "Comm1",
			"CommonRefZ:="		, "25ohm",
			"DiffName:="		, "Diff1",
			"DiffRefZ:="		, "100ohm",
			"IsActive:="		, True,
			"UseMatched:="		, False
		]
	])
oModule.EditDiffPairs(
	[
		"NAME:EditDiffPairs",
		[
			"NAME:Pair1",
			"PosBoundary:="		, "traceN_T1",
			"NegBoundary:="		, "traceP_T1",
			"CommonName:="		, "Comm1",
			"CommonRefZ:="		, "25ohm",
			"DiffName:="		, "Diff1",
			"DiffRefZ:="		, "100ohm",
			"IsActive:="		, True,
			"UseMatched:="		, False
		],
		[
			"NAME:Pair2",
			"PosBoundary:="		, "traceN_T2",
			"NegBoundary:="		, "traceP_T2",
			"CommonName:="		, "Comm2",
			"CommonRefZ:="		, "25ohm",
			"DiffName:="		, "Diff2",
			"DiffRefZ:="		, "100ohm",
			"IsActive:="		, True,
			"UseMatched:="		, False
		]
	])
oModule = oDesign.GetModule("AnalysisSetup")
oModule.InsertSetup("HfssDriven", 
	[
		"NAME:Setup1",
		"AdaptMultipleFreqs:="	, False,
		"Frequency:="		, "5GHz",
		"MaxDeltaS:="		, 0.02,
		"PortsOnly:="		, False,
		"UseMatrixConv:="	, False,
		"MaximumPasses:="	, 6,
		"MinimumPasses:="	, 1,
		"MinimumConvergedPasses:=", 1,
		"PercentRefinement:="	, 30,
		"IsEnabled:="		, True,
		"BasisOrder:="		, 1,
		"DoLambdaRefine:="	, True,
		"DoMaterialLambda:="	, True,
		"SetLambdaTarget:="	, False,
		"Target:="		, 0.3333,
		"UseMaxTetIncrease:="	, False,
		"PortAccuracy:="	, 2,
		"UseABCOnPort:="	, False,
		"SetPortMinMaxTri:="	, False,
		"UseDomains:="		, False,
		"UseIterativeSolver:="	, False,
		"SaveRadFieldsOnly:="	, False,
		"SaveAnyFields:="	, True,
		"IESolverType:="	, "Auto",
		"LambdaTargetForIESolver:=", 0.15,
		"UseDefaultLambdaTgtForIESolver:=", True
	])
oModule.InsertFrequencySweep("Setup1", 
	[
		"NAME:Sweep",
		"IsEnabled:="		, True,
		"RangeType:="		, "LinearCount",
		"RangeStart:="		, "0GHz",
		"RangeEnd:="		, "10GHz",
		"RangeCount:="		, 451,
		"Type:="		, "Interpolating",
		"SaveFields:="		, False,
		"SaveRadFields:="	, False,
		"InterpTolerance:="	, 0.5,
		"InterpMaxSolns:="	, 250,
		"InterpMinSolns:="	, 0,
		"InterpMinSubranges:="	, 1,
		"ExtrapToDC:="		, True,
		"MinSolvedFreq:="	, "0.01GHz",
		"InterpUseS:="		, True,
		"InterpUsePortImped:="	, True,
		"InterpUsePropConst:="	, True,
		"UseDerivativeConvergence:=", False,
		"InterpDerivTolerance:=", 0.2,
		"UseFullBasis:="	, True,
		"EnforcePassivity:="	, True,
		"PassivityErrorTolerance:=", 0.0001,
		"EnforceCausality:="	, False
	])
oProject.Save()
oDesign.AnalyzeAll()

oModule = oDesign.GetModule("ReportSetup")
oModule.CreateReport("Terminal S Parameter Plot 1", "Terminal Solution Data", "Rectangular Plot", "Setup1 : Sweep", 
	[
		"Domain:="		, "Sweep"
	], 
	[
		"Freq:="		, ["All"]
	], 
	[
		"X Component:="		, "Freq",
		"Y Component:="		, ["dB(St(Diff1,Diff1))","dB(St(Diff2,Diff1))"]
	], [])
oModule.ChangeProperty(
	[
		"NAME:AllTabs",
		[
			"NAME:Trace",
			[
				"NAME:PropServers", 
				"Terminal S Parameter Plot 1:dB(St(Diff2,Diff1))"
			],
			[
				"NAME:ChangedProps",
				[
					"NAME:Y Axis",
					"Value:="		, "Y2"
				]
			]
		]
	])
